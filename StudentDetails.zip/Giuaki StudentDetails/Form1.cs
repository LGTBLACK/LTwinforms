﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Giuaki_StudentDetails
{
    
    public partial class Form1 : Form
    {
        DataTable table = new DataTable("table");
        int index;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            table.Columns.Add("ID", Type.GetType("System.Int32"));
            table.Columns.Add("Student Name", Type.GetType("System.String"));
            table.Columns.Add("Age", Type.GetType("System.Int32"));
            table.Columns.Add("Gender", Type.GetType("System.String"));
            table.Columns.Add("City", Type.GetType("System.String"));
            dataGridView1.DataSource = table;
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            table.Rows.Add(textID.Text, textName.Text, textAge.Text, textGender.Text, textCity.Text);
        }

       
           
           private void btnNew_Click(object sender, EventArgs e)
                    {
                        textID.Text = string.Empty;
                        textName.Text = string.Empty;
                        textAge.Text = string.Empty;
                        textGender.Text = string.Empty;
                        textCity.Text = string.Empty;
                    }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            index = e.RowIndex;
            DataGridViewRow row = dataGridView1.Rows[index];
            textID.Text = row.Cells[0].Value.ToString();
            textName.Text = row.Cells[1].Value.ToString();
            textAge.Text = row.Cells[2].Value.ToString();
            textGender.Text = row.Cells[3].Value.ToString();
            textCity.Text = row.Cells[4].Value.ToString();


        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            DataGridViewRow newdata = dataGridView1.Rows[index];
            newdata.Cells[0].Value = textID.Text;
            newdata.Cells[1].Value = textName.Text;
            newdata.Cells[2].Value = textAge.Text;
            newdata.Cells[3].Value = textGender.Text;
            newdata.Cells[4].Value = textCity.Text;

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            index = dataGridView1.CurrentCell.RowIndex;
            dataGridView1.Rows.RemoveAt(index);
        }
    }
}
